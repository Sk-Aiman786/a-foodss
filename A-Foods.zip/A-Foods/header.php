<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="./css/responsive.css">

</head>
<body>
<?php
include 'session.php'; 

if(isset($_SESSION['card'])){
$a = count ($_SESSION['card']);
}else
{
    $a = 0;
}



?>

<header id = "Home">
    <nav class="navbar navbar-expand-lg navbar-light navbar-head">
      <div class="container">
        <a class="navbar-brand" href="#"><img src="./assets/A-FOODS Logo 3.png" alt="" /></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarNav">
          <ul class="navbar-nav  ms-auto">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#Home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="About-us.html">About us</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#Menu" id="navbarDropdown" role="button"
                data-bs-toggle="dropdown">Menu</a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li>
                  <a class="dropdown-item" href="menu bargur.html">Menu 1</a>
                </li>
                <li>
                  <a class="dropdown-item" href="menu-page-2.html">Menu 2</a>
                </li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link  dropdown-toggle" href="#Menu" id="navbarDropdown" role="button" data-bs-toggle="dropdown" >Product</a>
              <!-- <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="product.html">Pizza</a></li>
                <li><a class="dropdown-item" href="product -3.html">Burger</a></li>
                <li><a class="dropdown-item" href="product - 4.html">Cake</a></li>
                <li><a class="dropdown-item" href="product - 2.html">Age Roll</a></li>
              </ul> -->
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li>
                  <a class="dropdown-item" href="product.html"
                    >chinese foods</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="product -3.html"
                    >italian food</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="product - 4.html"
                    >ramen foods</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="product - 2.html"
                    >Tortilla foods</a
                  >
                </li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.html">Contact</a>
            </li>
            <li class="nav-item position-relative">
              <a class="nav-link" aria-current="page" href="card.php"><i class="fa-solid fa-cart-shopping"></i><span class="text-danger position-absolute  " style="top:1%;" ><?php echo $a;?></span></a>
            </li>
            <?php
          if (isset($_SESSION['phone'])) {
 $HOST = 'localhost';
 $USER = 'root';
$PASS = '';
 $DB = 'a-foods';
 $id = $_SESSION['id'];
$con = new MySQLi($HOST,$USER,$PASS,$DB);
if($con->connect_error){
    die($con->connect_error);
}else{
    $SQL = "SELECT * FROM user WHERE user_id = $id";
    $result = $con->query($SQL);
    $row = $result->fetch_array();
    $con->close();
} 
            echo '<li class="nav-item dropdown">
            <a class="nav-link" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <img  src='.$row['profile_pic'].' class="rounded-circle w-100" alt="" style="width: 30% !important;" >
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="edit-profile.php">Edit Profile</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="./logout.php">Logout</a></li>
            </ul>
          </li>';
          }
          else {
            echo '<a href="login-from.html"><button type="button" class="btn btn-primary">
            Login
            </button></a>';
          }
          ?>
          </ul>
        </div>
      </div>
    </nav>
  </header>

</body>
</html>