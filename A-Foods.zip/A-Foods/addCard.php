<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST"){
if(isset($_POST['submit'])){
if(isset($_SESSION['card'])){

    $item_array_id = array_column($_SESSION['card'],'id');
    if(in_array($_POST['id'],$item_array_id)){
        echo "<script>alert('Product is already added in the cart..!')</script>";
        echo "<script>window.location = 'index.php'</script>";
    }
else{
    $count = count($_SESSION['card']);
    $_SESSION['card'][$count] = array('name'=>$_POST['name'],'price'=>$_POST['price'],'image'=>$_POST['image'],'quentity'=>$_POST['quentity'],'id'=>$_POST['id']);
    
    echo "<script>alert('Product is  added in the cart..!')</script>";
        echo "<script>window.location = 'index.php'</script>";}
}
else{
    $_SESSION['card'][0] = array('name'=>$_POST['name'],'price'=>$_POST['price'],'image'=>$_POST['image'],'quentity'=>1,'id'=>$_POST['id']);
    echo "<script>alert('Product is  added in the cart..!')</script>";
        echo "<script>window.location = 'index.php'</script>";
}

}
if(isset($_POST['delete'])){
    foreach($_SESSION['card'] as $key => $value){
        if($value['id'] == $_POST['id']){
            unset($_SESSION['card'][$key]);
        }
    }
    echo "<script>alert('Product is removed from the cart..!')</script>";
        echo "<script>window.location = 'card.php'</script>";
}
if(isset($_POST['quentity'])){
    foreach($_SESSION['card'] as $key => $value){
        if($value['id'] == $_POST['id']){
            $_SESSION['card'][$key]['quentity'] = $_POST['quentity'];
        }
    }
    echo "<script>window.location = 'card.php'</script>";
}
}
?>