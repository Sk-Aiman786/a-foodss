<?php
include "session.php";
print_r($_POST);
if(isset($_SESSION['phone'])){
   $id =$_SESSION['id'];
$email = $_POST['email'];

$HOST = 'localhost';
$USER = 'root';
$PASS = '';
$DB = 'a-foods';

$con = new mysqli($HOST, $USER, $PASS, $DB);
try {
if ($con->connect_error) {
    die('Connection Failed : '.$con->connect_error);
} else {
    $SQL = "INSERT INTO subcribe ( email,user_id) VALUES ( '$email','$id')";
     $con->query($SQL);
     $row = $con->affected_rows;
    $con->close();
    if ($row == 1) {
        echo"<script>window.location.href='index.php'; window.alert('You are subcribed successfully');</script>";
    }else{
        echo"<script>window.location.href='index.php'; window.alert('user already subcribed');</script>";
        
    }
}
}
catch (Exception $e) {
     $e->getMessage();
}
finally {
    echo"<script>window.location.href='index.php'; window.alert('user already subcribed');</script>";
}}
else{
    header('location:login-from.html');
}

?>