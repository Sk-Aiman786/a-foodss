<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>A-Foods</title>
    <link rel="icon" type="image/jpg" href="./assets/logo-web.jpg" />
    <!-- main css -->
    <link rel="stylesheet" href="./css/product.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
    />
    <!-- bootstrap css -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
      crossorigin="anonymous"
    />
    <!-- Link Swiper's CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  </head>

  <body>
    <!-- Header -->
    <?php
include 'session.php'; 

if(isset($_SESSION['card'])){
$a = count ($_SESSION['card']);
}else
{
    $a = 0;
}
?>
  <!-- Header -->
  <header id = "Home">
    <nav class="navbar navbar-expand-lg navbar-light navbar-head">
      <div class="container">
        <a class="navbar-brand" href="#"><img src="./assets/A-FOODS Logo 3.png" alt="" /></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link " aria-current="page" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="About-us.php">About us</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#Menu" id="navbarDropdown" role="button"
                data-bs-toggle="dropdown">Menu</a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li>
                  <a class="dropdown-item" href="menu bargur.php">Menu 1</a>
                </li>
                <li>
                  <a class="dropdown-item" href="menu-page-2.php">Menu 2</a>
                </li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link  dropdown-toggle active " href="#Menu" id="navbarDropdown" role="button" data-bs-toggle="dropdown" >Product</a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li>
                  <a class="dropdown-item" href="product.php"
                    >chinese foods</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="product -3.php"
                    >italian food</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="product - 4.php"
                    >ramen foods</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="product - 2.php"
                    >Tortilla foods</a
                  >
                </li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
            <li class="nav-item position-relative">
              <a class="nav-link" aria-current="page" href="card.php"><i class="fa-solid fa-cart-shopping"></i><span class="text-danger position-absolute  " style="top:1%;" ><?php echo $a;?></span></a>
            </li>
            <?php
          if (isset($_SESSION['phone'])) {
 $HOST = 'localhost';
 $USER = 'root';
$PASS = '';
 $DB = 'a-foods';
 $id = $_SESSION['id'];
$con = new MySQLi($HOST,$USER,$PASS,$DB);
if($con->connect_error){
    die($con->connect_error);
}else{
    $SQL = "SELECT * FROM user WHERE user_id = $id";
    $result = $con->query($SQL);
    $row = $result->fetch_array();
    $con->close();
} 
            echo '<li class="profile dropdown">
            <a class="nav-link" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <img  src='.$row['profile_pic'].' class="rounded-circle w-100" alt="" style="width: 20% !important;" >
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="edit-profile.php">Edit Profile</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="./logout.php">Logout</a></li>
            </ul>
          </li>';
          }
          else {
            echo '<a href="login-from.html"><button type="button" class="btn btn-primary">
            Login
            </button></a>';
          }
          ?>
          </ul>
        </div>
      </div>
    </nav>
  </header>
    <!-- banner -->
    <section class="banner">
      <div class="container">
        <div class="row">
          <div class="col-12 text-center">
            <h3>
              <a href="index.php">Home </a
              ><i class="fa fa-arrow-left" aria-hidden="true"></i> Product
            </h3>
          </div>
        </div>
      </div>
    </section>
    <!-- product -->
    <section class="product">
      <div class="container">
        <div class="title-product">
          <div class="row">
            <div class="col-12 text-center pb-4">
              <h5>Chinese Foods</h5>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-xl-6 text-center col-md-12 product-1">
            <img src="./assets/menu-1.jpg" alt="" />
          </div>
          <div
            class="col-xl-6 col-lg-6 text-center text-lg-start pt-lg-0 pt-sm-2 col-md-12 col-sm-12"
          >
            <p class="">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s.
            </p>
            <div class="div pb-lg-4 pb-sm-0 pb-md-2">
              <label> Reviews :</label>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                version="1.1"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                width="20"
                height="20"
                x="0"
                y="0"
                viewBox="0 0 512 512"
                style="enable-background: new 0 0 512 512"
                xml:space="preserve"
                class=""
              >
                <g>
                  <path
                    d="m512 197.816-186.039-12.231L255.898 9.569l-70.063 176.016L0 197.816l142.534 121.026-46.772 183.589L255.898 401.21l160.137 101.221-46.772-183.589z"
                    fill="#ffed00"
                    opacity="1"
                    data-original="#000000"
                    class=""
                  ></path>
                </g>
              </svg>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                version="1.1"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                width="20"
                height="20"
                x="0"
                y="0"
                viewBox="0 0 512 512"
                style="enable-background: new 0 0 512 512"
                xml:space="preserve"
                class=""
              >
                <g>
                  <path
                    d="m512 197.816-186.039-12.231L255.898 9.569l-70.063 176.016L0 197.816l142.534 121.026-46.772 183.589L255.898 401.21l160.137 101.221-46.772-183.589z"
                    fill="#ffed00"
                    opacity="1"
                    data-original="#000000"
                    class=""
                  ></path>
                </g>
              </svg>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                version="1.1"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                width="20"
                height="20"
                x="0"
                y="0"
                viewBox="0 0 512 512"
                style="enable-background: new 0 0 512 512"
                xml:space="preserve"
                class=""
              >
                <g>
                  <path
                    d="m512 197.816-186.039-12.231L255.898 9.569l-70.063 176.016L0 197.816l142.534 121.026-46.772 183.589L255.898 401.21l160.137 101.221-46.772-183.589z"
                    fill="#ffed00"
                    opacity="1"
                    data-original="#000000"
                    class=""
                  ></path>
                </g>
              </svg>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                version="1.1"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                width="20"
                height="20"
                x="0"
                y="0"
                viewBox="0 0 512 512"
                style="enable-background: new 0 0 512 512"
                xml:space="preserve"
                class=""
              >
                <g>
                  <path
                    d="m512 197.816-186.039-12.231L255.898 9.569l-70.063 176.016L0 197.816l142.534 121.026-46.772 183.589L255.898 401.21l160.137 101.221-46.772-183.589z"
                    fill="#ffed00"
                    opacity="1"
                    data-original="#000000"
                    class=""
                  ></path>
                </g>
              </svg>
            </div>
            <p>
              <strike>$29.00</strike> <span class="rs">$25.52 </span>Save 12%
            </p>
            <label class="pb-2">Quentity :</label>
            <form action="addCard.php" method="post">
            <p>
              <button id="dec" class="br" type="button">-</button>
              <input type="number" name="quentity" value="1" id="input" />
              <button id="inc" type="button" class="br">+</button>
            </p>
          <?php
    const HOST = 'localhost'; 
    const USER = 'root';
    const PASS = '';
    const DB = 'a-foods';
    $con = new MySQLi(HOST,USER,PASS,DB);
    if($con->connect_error){
      die($con->connect_error);
    }
    $sql = "SELECT * FROM item where p_id =2";
    $result = $con->query($sql);
    $row = $result->fetch_array();
    $con->close();
    ?>
          <input type="hidden" name="image" value="<?php echo $row['p_pic'] ; ?>" id="p_id">
          <input type="hidden" name="name" value="<?php echo $row['p_name'] ; ?>" id="p_id">
          <input type="hidden" name="id" value="<?php echo $row['p_id'] ; ?>" id="p_id">
          <input type="hidden" name="price" value="<?php echo $row['price'] ; ?>" id="p_id">
          <button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Add To Card</button>
          </form>
          </div>
        </div>
      </div>
    </section>
    <!-- menu -->
    <section class="menu">
      <!-- <div class="row">
        <div class="col-12">
          <!-- <div class="title-menu text-center pb-4">
            <h3>Menu !</h3>
          </div> -->
        </div>
      </div> -->
      <div class="container">
        <div class="swiper mySwiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <img src="./assets/index-03-566x401 (1).jpg" alt="" />
              <div class="div d-flex mt-3">
                <a
                  href="product - 4.php"
                  class="d-flex text-dark text-decoration-none"
                >
                  <h5>Swiss cutlet</h5>
                  <h6>$7.09</h6>
                </a>
              </div>
              <a href="product - 4.php" class="text-dark text-decoration-none">
                <p>
                  200g of Black Angus steak, french fries, Coleslav salad, beer
                </p>
              </a>
            </div>

            <div class="swiper-slide">
              <img class="bur" src="./assets/menu-2.jpg" alt="" />
              <div class="div d-flex mt-3">
                <a href="product - 5.php" class="d-flex text-dark text-decoration-none">
                  <h5>Laverstroke</h5>
                  <h6>$7.09</h6>
                </a>
              </div>
              <a href="product - 5.php" class="text-dark text-decoration-none">
                <p>with English watercress & hazelnuts</p>
              </a>
            </div>
            <div class="swiper-slide">
              <img src="./assets/menu-3.jpg" alt="" />
              <div class="div d-flex mt-3">
                <a
                  href="product - 2.php"
                  class="d-flex text-dark text-decoration-none"
                >
                  <h5>Polish plate</h5>
                  <h6>$7.09</h6>
                </a>
              </div>
              <a href="product - 2.php" class="text-dark text-decoration-none">
                <p>with Winter black truffles from Piedmont</p>
              </a>
            </div>
            <div class="swiper-slide">
              <img src="./assets/index-01-566x401.jpg" alt="" />
              <div class="div d-flex mt-3">
                <a
                  href="product -3.php"
                  class="d-flex text-dark text-decoration-none"
                >
                  <h5>Black angus</h5>
                  <h6>$7.09</h6>
                </a>
              </div>
              <a href="product -3.php" class="text-dark text-decoration-none">
                <p>with Winter black truffles from Piedmont</p>
              </a>
            </div>
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </section>
    <section class="Reviwe">
      <div class="container d-block">
        <div class="row">
          <div class="col-12 text-center mb-lg-2 mb-sm-0">
            <h3>Clint Reviwes</h3>
          </div>
        </div>
        <hr>
        <div class="row ">
          <div class="col-3 text-center align-content-center">
            <img  src="./assets/testimonial-S1-Images-1.png" alt="">
          </div>
          <div class="col-9">
            <h5 class="mt-lg-3 mt-md-0">"H. Rackham"<i class="fa fa-star ms-4 me-2" aria-hidden="true"></i><i class="fa fa-star me-2" aria-hidden="true"></i><i class="fa fa-star me-2" aria-hidden="true"></i><i class="fa fa-star-o me-2" aria-hidden="true"></i><i class="fa fa-star-o me-2" aria-hidden="true"></i></h5>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p>
          </div>
        </div>
        <hr>
        <div class="row mt-lg-4 mt-sm-0">
          <div class="col-3 text-center align-content-center">
            <img  src="./assets/testimonial-S1-Images-2.png" alt="">
          </div>
          <div class="col-9">
            <h5 class="mt-3 mt-md-0">"Bonorum et Malorum"<i class="fa fa-star ms-4  me-2" aria-hidden="true"></i><i class="fa fa-star me-2" aria-hidden="true"></i><i class="fa fa-star me-2" aria-hidden="true"></i><i class="fa fa-star me-2" aria-hidden="true"></i><i class="fa fa-star me-2" aria-hidden="true"></i></h5>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p>
          </div>
        </div>
          <!-- <div class="col-9">
            <h5 class="mt-3 dog">"Bonorum et Malorum"</h5>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p>
          </div>
          <div class="col-3 text-center align-content-center">
            <img  src="./assets/testimonial-S1-Images-2.png" alt="">
          </div> -->
        </div>
        <hr>
      </div>
    </section>
    <!-- footer -->
     
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-xl-4 col-sm-6 mb-5 mb-lg-0 mb-xl-0">
            <ul>
              <img class="mb-4" src="./assets/A-FOODS Logo 5.png" alt="" />
              <p>
                Lorem Ipsum is simply dummy text of the prin ting and
                typesetting ind ustry. Lorem Ipsum has been the industry's sta
                ndard dummy.
              </p>
            </ul>
          </div>
          <div
            class="col-lg-3 col-xl-3 col-sm-6 mb-5 mb-lg-0 mb-xl-0 align-content-center"
          >
            <h5 class="fw-bold heading">Quick Links</h5>
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="About-us.php">About us </a></li>
              <li><a href="menu bargur.php">Menu </a></li>
              <li><a href="product.php">product </a></li>
              <li><a href="contact.php"> Contact</a></li>
            </ul>
          </div>
          <div class="col-lg-5 col-xl-5 col-sm-6 mb-5 mb-lg-xl-0">
            <h5 class="fw-bold pb-3">Newsletter</h5>
            <form action="subcribe.php" method="post">
          <div class="form-group mb-4">
            <input type="email" class="form-control" id="sub" name="email" placeholder="Enter Your Email" />
            <button  type="submit" class="btn btn-primary">Subcribe</button>
          </div>
        </form>
            <div class="icon">
              <a href="UCGjKJ1xC8UTPlcB3Dl-0MgQ" class="me-4"
                ><svg
                  xmlns="http://www.w3.org/2000/svg"
                  version="1.1"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                  width="30"
                  height="30"
                  x="0"
                  y="0"
                  viewBox="0 0 512 512"
                  style="enable-background: new 0 0 512 512"
                  xml:space="preserve"
                  class="hovered-paths"
                >
                  <g>
                    <path
                      fill="#1877f2"
                      d="M512 256c0 127.78-93.62 233.69-216 252.89V330h59.65L367 256h-71v-48.02c0-20.25 9.92-39.98 41.72-39.98H370v-63s-29.3-5-57.31-5c-58.47 0-96.69 35.44-96.69 99.6V256h-65v74h65v178.89C93.62 489.69 0 383.78 0 256 0 114.62 114.62 0 256 0s256 114.62 256 256z"
                      opacity="1"
                      data-original="#1877f2"
                      class="hovered-path"
                    ></path>
                    <path
                      fill="#ffffff"
                      d="M355.65 330 367 256h-71v-48.021c0-20.245 9.918-39.979 41.719-39.979H370v-63s-29.296-5-57.305-5C254.219 100 216 135.44 216 199.6V256h-65v74h65v178.889c13.034 2.045 26.392 3.111 40 3.111s26.966-1.066 40-3.111V330z"
                      opacity="1"
                      data-original="#ffffff"
                      class="me-2"
                    ></path>
                  </g></svg
              ></a>
              <a href="#" class="me-4"
                ><svg
                  xmlns="http://www.w3.org/2000/svg"
                  version="1.1"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                  width="30"
                  height="30"
                  x="0"
                  y="0"
                  viewBox="0 0 112.196 112.196"
                  style="enable-background: new 0 0 512 512"
                  xml:space="preserve"
                  class="hovered-paths"
                >
                  <g>
                    <circle
                      cx="56.098"
                      cy="56.097"
                      r="56.098"
                      style=""
                      fill="#007ab9"
                      data-original="#007ab9"
                      class="hovered-path"
                    ></circle>
                    <path
                      d="M89.616 60.611v23.128H76.207V62.161c0-5.418-1.936-9.118-6.791-9.118-3.705 0-5.906 2.491-6.878 4.903-.353.862-.444 2.059-.444 3.268v22.524h-13.41s.18-36.546 0-40.329h13.411v5.715c-.027.045-.065.089-.089.132h.089v-.132c1.782-2.742 4.96-6.662 12.085-6.662 8.822 0 15.436 5.764 15.436 18.149zm-54.96-36.642c-4.587 0-7.588 3.011-7.588 6.967 0 3.872 2.914 6.97 7.412 6.97h.087c4.677 0 7.585-3.098 7.585-6.97-.089-3.956-2.908-6.967-7.496-6.967zm-6.791 59.77H41.27v-40.33H27.865v40.33z"
                      style=""
                      fill="#f1f2f2"
                      data-original="#f1f2f2"
                      class=""
                    ></path>
                  </g></svg
              ></a>
              <a href="#"
                ><svg
                  xmlns="http://www.w3.org/2000/svg"
                  version="1.1"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                  width="30"
                  height="30"
                  x="0"
                  y="0"
                  viewBox="0 0 152 152"
                  style="enable-background: new 0 0 512 512"
                  xml:space="preserve"
                  class=""
                >
                  <g>
                    <g data-name="Layer 2">
                      <g data-name="04.Twitter">
                        <circle
                          cx="76"
                          cy="76"
                          r="76"
                          fill="#03a9f4"
                          opacity="1"
                          data-original="#03a9f4"
                          class=""
                        ></circle>
                        <path
                          fill="#ffffff"
                          d="M125.23 45.47a42 42 0 0 1-11.63 3.19 20.06 20.06 0 0 0 8.88-11.16 40.32 40.32 0 0 1-12.8 4.89 20.18 20.18 0 0 0-34.92 13.8 20.87 20.87 0 0 0 .47 4.6 57.16 57.16 0 0 1-41.61-21.11 20.2 20.2 0 0 0 6.21 27 19.92 19.92 0 0 1-9.12-2.49v.22a20.28 20.28 0 0 0 16.17 19.82 20.13 20.13 0 0 1-5.29.66 18 18 0 0 1-3.83-.34 20.39 20.39 0 0 0 18.87 14.06 40.59 40.59 0 0 1-25 8.61 36.45 36.45 0 0 1-4.83-.28 56.79 56.79 0 0 0 31 9.06c37.15 0 57.46-30.77 57.46-57.44 0-.89 0-1.75-.07-2.61a40.16 40.16 0 0 0 10.04-10.48z"
                          opacity="1"
                          data-original="#ffffff"
                          class=""
                        ></path>
                      </g>
                    </g>
                  </g></svg
              ></a>
            </div>
          </div>
        </div>
        <hr />
        <div class="copy text-center">
          <h6><span class="color">Copyright @ 2024 By</span> A-Foods. Aiman</h6>
        </div>
      </div>
    </footer>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <!-- Initialize Swiper -->
    <script>
      var swiper = new Swiper(".mySwiper", {
        slidesPerView: 3,
        spaceBetween: 30,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });
    </script>
    <!-- slide up -->
    <div id="slidUp">
      <a href="#Home"><span class="fa fa-arrow-up fs-4 text-white"></span></a>
    </div>
    <!-- javascript -->
    <script>
      function scrollTopBack() {
        let scrollTopButton = document.querySelector("#slidUp");
        window.onscroll = function () {
          var scroll = document.documentElement.scrollTop;
          if (scroll >= 250) {
            scrollTopButton.classList.add("slideStart");
          } else {
            scrollTopButton.classList.remove("slideStart");
          }
        };
      }
      scrollTopBack();
    </script>
    <script>
      var b1 = document.getElementById("dec");
      var b2 = document.getElementById("inc");
      var a;
      b2.addEventListener("click", function () {
        var a = document.getElementById("input").value;
        a++;
        document.getElementById("input").value = a;
        if (a <= 1) {
          b1.disabled = true;
        } else {
          b1.disabled = false;
        }
      });
      b1.addEventListener("click", function () {
        var a = document.getElementById("input").value;
        a--;
        document.getElementById("input").value = a;
        if (a <= 1) {
          b1.disabled = true;
        } else {
          b1.disabled = false;
        }
      });
    </script>
    <!-- bootstrap javacript -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
