<?php
print_r($_POST);
if($_SERVER['REQUEST_METHOD'] == 'POST'){
if(isset($_POST['delete'])){
    $id = $_POST['id'];
    $con = mysqli_connect('localhost','root','','a-foods');
    $sql = "DELETE FROM `orders` WHERE `order_id` = '$id'";
    $result = mysqli_query($con,$sql);
    $con->close();
    if($result){
        echo "<script>window.alert('order deleted successfully');window.location.href='orders.php';</script>";     
    }   
}
if(isset($_POST['cancel'])){
    $id = $_POST['id'];
    $con = mysqli_connect('localhost','root','','a-foods');
    $sql = "UPDATE `orders` SET `status` = 'canceled' WHERE `order_id` = '$id'";
    $result = mysqli_query($con,$sql);
    $con->close();
    if($result){
        echo "<script>window.alert('order canceled successfully');window.location.href='orders.php';</script>";     
    }   
}

if(isset($_POST['delevered'])){
    $id = $_POST['id'];
    $con = mysqli_connect('localhost','root','','a-foods');
    $sql = "UPDATE `orders` SET `status` = 'delevered' WHERE `order_id` = '$id'";
    $result = mysqli_query($con,$sql);
    $con->close();
    if($result){
        echo "<script>window.alert('order delevered successfully');window.location.href='orders.php';</script>";     
    }       
}
}
?>