<?php
$id = $_POST['id'];

$HOST = "localhost";
$USER = "root";
$PASS = "";
$DB = "a-foods";
$con= new MySQLi($HOST, $USER, $PASS, $DB);
if($con->connect_error){
    die($con->connect_error);
}else{
    $SQL = "DELETE FROM `contact` WHERE c_id = $id";
    $result = $con->query($SQL);
    $con->close();
    if($result){
        echo "<script>window.alert('massage deleted successfully');window.location.href='contact.php';</script>";
    }
}
?>