<?php
print_r($_POST);
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(isset($_POST['submit'])){
      $name = $_POST['name'];
      $price = $_POST['price'];
      $description = $_POST['description'];

      $imge =$_FILES['avatar']['name'];
      $tmp = $_FILES['avatar']['tmp_name'];
      $type = $_FILES['avatar']['type'];
      $path ='../assets/';
      $paths ='./assets/';
      $imgPath = $path.$imge;
      $itemimgPath = $paths.$imge;
      if($type == 'image/jpg' || $type == 'image/jpeg' || $type == 'image/png' || $type == 'image/gif'){
        move_uploaded_file($tmp,$imgPath);
        $HOST = "localhost";
$USER = "root";
 $PASS = "";
$DB = "a-foods";

$con= new  MySQLi($HOST, $USER, $PASS, $DB);
        $sql = "INSERT INTO `item` ( `p_name`, `price`, `p_description`, `p_pic`) VALUES ( '$name', '$price', '$description', '$itemimgPath')";
        $result = $con->query($sql);
        $con->close();
        if($result){
            echo "<script>window.alert('item added successfully');window.location.href='items.php';</script>";
        }
    }else{
        echo "<script>window.alert('Only Image FIles are accepted....');window.location.href='items.php';</script>";
    }
}
if(isset($_POST['delete'])){
    $id = $_POST['id'];

    $HOST = "localhost";
    $USER = "root";
     $PASS = "";
    $DB = "a-foods";
    
    $con= new  MySQLi($HOST, $USER, $PASS, $DB);

    $sql = "DELETE FROM `item` WHERE p_id = $id";
    $result = $con->query($sql);
    $con->close();
    if($result){
        echo "<script>window.alert('item deleted successfully');window.location.href='items.php';</script>";
    }
}
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $prev_price = $_POST['p_price'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $imge =$_FILES['avatar']['name'];
    $tmp = $_FILES['avatar']['tmp_name'];
    $type = $_FILES['avatar']['type'];
    $path ='../assets/';
    $paths ='./assets/';
    $imgPath = $path.$imge;
    $itemimgPath = $paths.$imge;

    $HOST = "localhost";
    $USER = "root";
    $PASS = "";
    $DB = "a-foods";
    
    $con= new  MySQLi($HOST, $USER, $PASS, $DB);
    $sql = "UPDATE `item` SET `p_name` = '$name', `price` = '$price', `p_description` = '$description' WHERE`p_id` = $id";
    $result = $con->query($sql);
    if($result){
        echo "<script>window.alert('item updated successfully');window.location.href='items.php';</script>";
    }
    else{
        echo "<script>window.alert('Only Image FIles are accepted....');window.location.href='items.php';</script>";
    }
    if($type == 'image/jpg' || $type == 'image/jpeg' || $type == 'image/png' || $type == 'image/gif'){
        move_uploaded_file($tmp,$imgPath);
        $sql = "UPDATE `item` SET  `p_pic` = '$itemimgPath' WHERE `item`.`p_id` = $id";
        $result = $con->query($sql);
        $con->close();
}
}
}

?>