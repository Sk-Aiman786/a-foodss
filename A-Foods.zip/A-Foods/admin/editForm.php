<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
    <?php
        const HOST ="localhost";
        const USER ='root';
        const PASS ='';
        const DB ='user_db';
        $userData=[];
        $userId = isset($_GET['id']) ? $_GET['id'] : NULL;
        if(!empty($userId)){
            $con=new MySQLi(HOST,USER,PASS,DB);
            if($con->connect_error) {
            die($con->connect_error);
        }else{
          $sql="select * from user where user_id=".$userId;
          $result=$con->query($sql);


            while($rows = $result->fetch_assoc()){
              $xyz = explode(' ',$rows['name']);

              $userData =[
                 // 'name'=>$rows['name'],
                'firstname' => $xyz[0],
                'middlename'=>$xyz[1],
                'phone'=> $rows['phone'],
                'email'=> $rows['email']

              ];
          }
          // print_r($userData);
          $con->close();
        }

        }
        else {
          echo "<script>
          alert('You are not authorized to access the Page');
          window.location.href='index.php';
          </script>";
      }
    ?>
<div class="container">
  <form action="update.php" method="post" >
  <header class="modal-header">
            <h4>Displaying <?php echo $userData['firstname'].' '.$userData['middlename'];?>'s Record.</h4>
        </header>
  <div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingInput" name="firstname"  value="<?php echo $userData['firstname'];?>" placeholder="name@example.com">
  <label for="floatingInput">First name</label>
</div>
<div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingPassword" name="lastname" value="<?php echo $userData['middlename'];?>" placeholder="Password">
  <label for="floatingPassword">last name</label>
</div>
<div class="form-floating mb-3">
  <input type="email" class="form-control" id="floatingInput" name="email" value="<?php echo $userData['email'] ;?>" placeholder="name@example.com">
  <label for="floatingInput">Email </label>
</div>
<div class="form-floating">
  <input type="number" class="form-control" name="phone"  value="<?php echo $userData['phone'];?>"  id="floatingPassword" placeholder="Password">
  <label for="floatingPassword">Phone </label>
  <input type="hidden" name="hid" value="<?php echo $userId; ?>">
</div>
<div class="form-group">
   <button type="submit" class="btn btn-sm btn-outline-primary mt-3 " >Update</button>
</div>
  </form>
</div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>