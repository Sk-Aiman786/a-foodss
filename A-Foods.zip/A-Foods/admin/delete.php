<?php
const HOST='localhost';
const USER='root';
const PASS='';
const DB ='user_db';
// $userId = isset($_GET(['id']) ? $_GET(['id']):NULL);
$userId = isset($_GET['id']) ? $_GET['id'] : NULL;
if(!empty($userId)){
$con = new MySQLi(HOST,USER,PASS,DB);
if($con->connect_error){
    die($con->connect_error);
}
else
{
    // $SQL="detet form user where user_id=".$userId;
    $SQL="delete from user where user_id=".$userId;
    $con->query($SQL);
    $rows=$con->affected_rows;
    $con->close();
    if($rows==1){
        echo "<script>
         alert('One User profile got deleted');
         window.location.href='index.php';
        </script>";
    }else{
        echo "<script>
        alert('Something went wrong !');
        window.location.href='index.php';
       </script>";
    }
}
}
else{
    echo "<script>
    alert('You are not authorized to view this Page');
    window.location.href='index.php';
    </script>";
}
?>