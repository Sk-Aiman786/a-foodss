<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
      .from-img{
        width: 400px;
        margin: 0 auto;
      }
      .from-img img{
        width: 100%;
        object-fit: cover;
      }
    </style>  
</head>
  <body>
    <?php
    $id = $_GET['id'];
    const HOST = "localhost";   
    const USER = "root";
    const PASS = "";
    const DB = "a-foods";
    $con= new  MySQLi(HOST, USER, PASS, DB);
    $sql = "SELECT * FROM `item` WHERE p_id = $id";
    $result = $con->query($sql);
    $row = $result->fetch_assoc(); 
     ?>
  <div class="container">
      <h3 class="text-center mt-4" >Add Items</h3>
    <form action="item.php" class="card p-4 mt-4" enctype="multipart/form-data" method="post">
        <div class="from-img">
            <img src=".<?php echo $row['p_pic']; ?>" id="avatar" alt="">
        </div>
    <div class="form-floating my-3">
  <input type="file" class="form-control" id="file" value="<?php echo $row['p_pic']; ?>" name="avatar" placeholder="name@example.com">
  <label for="floatingInput">Name picture</label>
</div>
    <div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingInput" value="<?php echo $row['p_name']; ?>" required name="name" placeholder="name@example.com">
  <label for="floatingInput">Item Name</label>
</div>
<div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingPassword" value="<?php echo $row['prev_price']; ?>" required name="p_price" placeholder="Password">
  <label for="floatingPassword">previus Price</label>
</div>

<div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingPassword" required name="price" value="<?php echo $row['price']; ?>" placeholder="Password">
  <label for="floatingPassword">Price</label>
</div>

<div class="form-floating">
  <input type="text" class="form-control" id="floatingPassword" required name="description" value="<?php echo $row['p_description']; ?>" placeholder="Password">
  <label for="floatingPassword">Description</label>
</div>
<div class="form-group">
    <input type="hidden" name="id" value="<?php echo $row['p_id']; ?>">
   <button type="submit" class="btn btn-sm btn-outline-primary mt-3 " name="update" >update</button>
</div>
</form>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>