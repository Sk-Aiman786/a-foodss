<?php
print_r($_POST);
$username = $_POST['firname'];
$pass = $_POST['pasword'];
session_start();
$id = $_SESSION['id'];
echo $id;

const HOST = 'localhost';
const USER = 'root';
const PASS = '';
const DB = 'a-foods';
$con = new MySQLi(HOST,USER,PASS,DB);
    if($con->connect_error){
        die($con->connect_error);
    }else{

        $SQL = "UPDATE admin SET user_name = '$username', password = '$pass' WHERE admin_id = $id";
    $result = $con->query($SQL);        
    
   echo"<script>window.location.href='index.php'; window.alert('You are updated successfully');</script>";
    }
?>