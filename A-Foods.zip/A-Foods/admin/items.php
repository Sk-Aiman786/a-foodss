<?php
session_start();
if(!isset($_SESSION['id'])){
  header('location:login.php');
}else{
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
 <link rel="stylesheet" href="../css/style.css" />
  
  <style>
      .from-img{
        width: 400px;
        margin: 0 auto;
      }
      .from-img img{
        width: 100%;
        object-fit: cover;
      }
    </style>
  </head>
  <body>
    <!-- header -->
    <header>
    <nav class="navbar navbar-expand-lg navbar-light navbar-head">
      <div class="container">
        <a class="navbar-brand" href="index.php"><img src="../assets/A-FOODS Logo 3.png" alt="" /></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link " aria-current="page" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="items.php">Food item</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="orders.php">Orders</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="subscribers.php">Subscribers</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
            <?php
          if (isset($_SESSION['id'])) {
 $HOST = 'localhost';
 $USER = 'root';
$PASS = '';
 $DB = 'a-foods';
 $id = $_SESSION['id'];
$con = new MySQLi($HOST,$USER,$PASS,$DB);
if($con->connect_error){
    die($con->connect_error);
}else{
    $SQL = "SELECT * FROM admin WHERE admin_id = $id";
    $result = $con->query($SQL);
    $row = $result->fetch_array();
    $con->close();
} 
            echo '<li class="profile dropdown">
            <a class="nav-link" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <button type="button" class="btn btn-danger">
            '.$row['user_name'].'
            </button>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="edit-profile.php">Edit Profile</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="./logout.php">Logout</a></li>
            </ul>
          </li>';
          }
          else {
            echo '<a href="login-from.html"><button type="button" class="btn btn-primary">
            Login
            </button></a>';
          }
          ?>
          </ul>
        </div>
      </div>
    </nav>
  </header>
    <!-- items -->
      <div class="container">
      <h3 class="text-center mt-4" >Add Items</h3>
    <form action="item.php" class="card p-4 mt-4" enctype="multipart/form-data" method="post">
        <div class="from-img">
            <img src="../assets/menu-1.jpg" id="avatar" alt="">
        </div>
    <div class="form-floating my-3">
  <input type="file" class="form-control" id="file" name="avatar" placeholder="name@example.com">
  <label for="floatingInput">Name picture</label>
</div>
    <div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingInput" required name="name" placeholder="name@example.com">
  <label for="floatingInput">Item Name</label>
</div>
<div class="form-floating mb-3">
  <input type="text" class="form-control" id="floatingPassword" required name="price" placeholder="Password">
  <label for="floatingPassword">Price</label>
</div>
<div class="form-floating">
  <input type="text" class="form-control" id="floatingPassword" required name="description" placeholder="Password">
  <label for="floatingPassword">Description</label>
</div>
<div class="form-group">
   <button type="submit" class="btn btn-sm btn-outline-primary mt-3 " name="submit" >Submit</button>
</div>
</form>
</div>

<h3 class="text-center mt-4" >All Items</h3>
<table class="table table-dark text-center">

<tr class="table-dark">
     <th class="table-dark">Id</th>
     <th class="table-dark">Image</th>
   <th class="table-dark">Name</th>
   <th class="table-dark">privius price</th>
   <th class="table-dark">Price</th>
   <th class="table-dark">Description</th>
   <th class="table-dark">Edit</th>
   <th class="table-dark">delete</th>
 </tr>

<?php

 $HOST = "localhost";
 $USER = "root";
 $PASS = "";
 $DB = "a-foods";

$con= new  MySQLi($HOST, $USER, $PASS, $DB);
if($con->connect_error){
    die($con->connect_error);
}else{
    $SQL = "SELECT * FROM item";
    $result = $con->query($SQL);
     while($row = $result->fetch_array()){
  ?>
<tr>
  <td ><?php echo $row['p_id'] ?></td>
  <td ><?php echo '<img src=.'.$row['p_pic'].' width="100" height="100">';?></td>
  <td ><?php echo $row['p_name']; ?></td>
  <td ><?php echo $row['prev_price']; ?></td>
  <td ><?php echo $row['price']; ?></td>
  <td ><?php echo $row['p_description']; ?></td>
  <td ><a href="editItem.php?id=<?php echo $row['p_id']; ?>" class="btn btn-sm btn-outline-primary" >Edit</a></td>
  <td ><form action="item.php" method="post">
    <input type="hidden" name="id" value="<?php echo $row['p_id']; ?>">
    <button class="btn btn-sm btn-outline-danger" type="submit" name="delete" >Delete</button></td>
  </form>
</tr>


<?php
      }
      $con->close();
    }
    ?>
    </table>
<script>
  let avatar = document.getElementById("file");
  let img = document.getElementById("avatar");
  console.log(avatar); //
  avatar.addEventListener("change", (e) => {
    img.src = URL.createObjectURL(e.target.files[0]);
  })
</script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
<?php
}
?>