<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>A-FOODS</title>
  <link rel="icon" type="image/jpg" href="./images/logo-web.jpg" />
  <!-- font awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Playwrite+AR:wght@100..400&family=Playwrite+BE+WAL:wght@100..400&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
    rel="stylesheet" />
  <!-- maim css -->
  <link rel="stylesheet" href="css/style.css" />
  <!-- responcive css -->
  <link rel="stylesheet" href="css/responciv.css" />
  <!-- bootrap css -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
  <!-- fontawesome 5 -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
</head>

<body id="body">
  <!-- Php -->
  <?php
include 'session.php'; 

if(isset($_SESSION['card'])){
$a = count ($_SESSION['card']);
}else
{
    $a = 0;
}
?>
  <!-- Header -->
  <header>
    <nav class="navbar navbar-expand-lg navbar-light navbar-head">
      <div class="container">
        <a class="navbar-brand" href="#"><img src="./assets/A-FOODS Logo 3.png" alt="" /></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#Home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="About-us.php">About us</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#Menu" id="navbarDropdown" role="button"
                data-bs-toggle="dropdown">Menu</a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li>
                  <a class="dropdown-item" href="menu bargur.php">Menu 1</a>
                </li>
                <li>
                  <a class="dropdown-item" href="menu-page-2.php">Menu 2</a>
                </li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link  dropdown-toggle" href="#Menu" id="navbarDropdown" role="button" data-bs-toggle="dropdown" >Product</a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li>
                  <a class="dropdown-item" href="product.php"
                    >chinese foods</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="product -3.php"
                    >italian food</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="product - 4.php"
                    >ramen foods</a
                  >
                </li>
                <li>
                  <a class="dropdown-item" href="product - 2.php"
                    >Tortilla foods</a
                  >
                </li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
            <li class="nav-item position-relative">
              <a class="nav-link" aria-current="page" href="card.php"><i class="fa-solid fa-cart-shopping"></i><span class="text-danger position-absolute  " style="top:1%;" ><?php echo $a;?></span></a>
            </li>
            <?php
          if (isset($_SESSION['phone'])) {
 $HOST = 'localhost';
 $USER = 'root';
$PASS = '';
 $DB = 'a-foods';
 $id = $_SESSION['id'];
$con = new MySQLi($HOST,$USER,$PASS,$DB);
if($con->connect_error){
    die($con->connect_error);
}else{
    $SQL = "SELECT * FROM user WHERE user_id = $id";
    $result = $con->query($SQL);
    $row = $result->fetch_array();
    $con->close();
} 
            echo '<li class="profile dropdown">
            <a class="nav-link" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <img  src='.$row['profile_pic'].' class="rounded-circle w-100" alt="" style="width: 20% !important;" >
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="edit-profile.php">Edit Profile</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="./logout.php">Logout</a></li>
            </ul>
          </li>';
          }
          else {
            echo '<a href="login-from.html"><button type="button" class="btn btn-primary">
            Login
            </button></a>';
          }
          ?>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  <!-- banner -->
  <section id="Home" class="Home">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-7 text-center text-lg-start order-lg-1 order-2">
          <h2>50% Discount</h2>
          <h1>delicious and healthy foods</h1>
          <div class="btn-Home mt-4 mt-md-1">
            <a href="menu bargur.html"><button type="button" class="btn btn-primary">
                View Menu
              </button></a>
            <a href="product.html"><button type="button" class="btn btn-secondary">
                Order Now
              </button></a>
          </div>
        </div>
        <div class="col-lg-5 text-center text-lg-start order-lg-2 order-1 banner">
          <img src="./assets/A-FOODS BANNER.png" alt="" />
        </div>
      </div>
    </div>
  </section>
  <!-- About us -->
  <section id="About-us">
    <div class="About-us-2">
      <div class="container">
        <div class="row">
          <div class="col-xl-7 col-lg-7 order-lg-1 order-2 about-img">
            <img src="./assets/index-gallery-2-480x394.jpg" alt="" />
          </div>

          <div class="col-xl-5 col-lg-5 order-lg-2 order-2">
            <div class="card">
              <div class="card-body">
                <h5>About Us</h5>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Quis doloremque mollitia id ad perspiciatis. Animi It is a
                  long established fact that a reader
                </p>
                <a href="About-us.html"><button type="button" class="btn btn-secondary mt-2">
                    Red More
                  </button></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- menu -->
  <?php
    const HOST = 'localhost'; 
    const USER = 'root';
    const PASS = '';
    const DB = 'a-foods';
    $con = new MySQLi(HOST,USER,PASS,DB);
    if($con->connect_error){
        die($con->connect_error);
    }
    $sql = "SELECT * FROM item";
    $result = $con->query($sql);
    $row = $result->fetch_array();
    $con->close();
    ?>
      <!-- menu -->
  <section id="Menu">
    <div class="title-menu text-center mb-5">
      <h5>Chef Recommends</h5>
      <p>Choose a perfect combination of main dish and wine, thanks to our Chef’s specials</p>
    </div>
    <div class="container">
      <div class="row">
  

        <?php
  while($row = $result->fetch_array()){
   echo '<div class="col-sm-6">
   <form action="addCard.php" method="post" >
          <a href="product - 2.php">
            <div class="card">
              <div class="ditles">
                <div class="about-6">
                  <h4>'.$row['p_name'].'</h4>
                  <p>
                    '.$row['p_description'].'
                  </p>
                  <h5>
                    <span class="color-1"><strike>'.$row['prev_price'].'</strike></span> $'.$row['price'].'
                  </h5>
                    <button type="submit" name="submit" class="btn btn-primary mt-4" >Add To Card</button>
                </div>
                <div class="about-7">
                      <img src='.$row['p_pic'].' alt="" />
                </div>
              </div>
            </div>
          </a>
          <input type="hidden" name="quentity" value="1" id="quentity">

          <input type="hidden" name="name" value="'.$row['p_name'].'" id="p_id">
          <input type="hidden" name="id" value="'.$row['p_id'].'" id="p_id">
          <input type="hidden" name="price" value="'.$row['price'].'" id="p_id">
          </form>
        </div>';
  }
  ?>

      </div>
    </div>
  </section>
  <!-- section -->
  <div class="section-2" id="counter">
    <div class="container">
      <div class="row row row-cols-1 row-cols-md-4 g-4 align-items-center">
        <div class="text-center revo">
          <h5><span id="count1"></span>+</h5>
          <p>savings</p>
        </div>
        <div class="text-center revo">
          <h5><span id="count2"></span>+</h5>
          <p>photos</p>
        </div>
        <div class="text-center revo">
          <h5><span id="count3"></span>+</h5>
          <p>rockets</p>
        </div>
        <div class="text-center revo">
          <h5><span id="count4"></span>+</h5>
          <p>globes</p>
        </div>
      </div>
    </div>
  </div>
  <!-- reviwe -->
  <section id="Reviwe" class="reviwe wrapper">
    <div class="container">
      <div class="title-reviwe pb-4 text-center">
        <h5>
          C<span class="color">lient </span>R<span class="color">eviwe</span>
        </h5>
      </div>
      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
            aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
            aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
            aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="carousel-caption">
              <img src="./assets/pic-2.png" alt="" />
              <h5>Jessy Priston</h5>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis
                doloremque mollitia id ad <br />
                perspiciatis Animi.
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <div class="carousel-caption">
              <img src="./assets/pic-3.png" alt="" />
              <h5>H. Rackham</h5>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis
                doloremque mollitia id ad <br />
                perspiciatisAnimi.
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <div class="carousel-caption">
              <img src="./assets/pic-1.png" alt="" />
              <h5>Bonorum et</h5>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis
                doloremque mollitia id ad <br />
                perspiciatisAnimi.
              </p>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
          data-bs-slide="prev">
          <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
          <!-- <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="30" height="30" x="0" y="0" viewBox="0 0 240.823 240.823" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M57.633 129.007 165.93 237.268c4.752 4.74 12.451 4.74 17.215 0 4.752-4.74 4.752-12.439 0-17.179l-99.707-99.671 99.695-99.671c4.752-4.74 4.752-12.439 0-17.191-4.752-4.74-12.463-4.74-17.215 0L57.621 111.816c-4.679 4.691-4.679 12.511.012 17.191z" fill="#000000" opacity="1" data-original="#000000" class=""></path></g></svg> -->
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
          data-bs-slide="next">
          <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
          <!-- <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="30" height="30" x="0" y="0" viewBox="0 0 240.823 240.823" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M183.189 111.816 74.892 3.555c-4.752-4.74-12.451-4.74-17.215 0-4.752 4.74-4.752 12.439 0 17.179l99.707 99.671-99.695 99.671c-4.752 4.74-4.752 12.439 0 17.191 4.752 4.74 12.463 4.74 17.215 0l108.297-108.261c4.68-4.691 4.68-12.511-.012-17.19z" fill="#000000" opacity="1" data-original="#000000" class=""></path></g></svg> -->
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </section>
  <!-- Contact -->
  <section id="Contact">
    <div class="container">
      <!-- <div class="title-contact text-center">
        <h5>
          <span class="color">C</span>ontact <span class="color">u</span>s!
        </h5>
      </div> -->
      <div class="row">
        <div class="col-lg-5 col-xl-5 cols-md-4 col-12 align-items-center">
          <div class="info align-content-center">
            <h4 class="fw-bold pb-4">Contact Info</h4>

            <p>
              <i class="fa fa-map-marker pe-4"></i><a href="#">Mumbai,India-40014</a>
            </p>

            <p>
              <i class="fa fa-mobile pe-4"></i><a href="#">+123-456-7890</a>
            </p>

            <p>
              <i class="fa fa-envelope pe-4"></i><a href="#">Abc@Gmail.Com</a>
            </p>
          </div>
        </div>
        <div class="col-xl-7 col-lg-7 cols-md-5 pt-lg-0 pt-md-0 pt-lg-0 pt-4">
          <form method="post" autocomplete="on" action="contact user.php">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <input type="text" id="t1" class="form-control" placeholder="Enter Your Name*" required
                    onkeyup="nameChake()" name ="name" />
                  <section id="errorName" class="text-danger"></section>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <input type="email" class="form-control" id="t2" placeholder="Enter Your Email*" required
                    onkeyup="emailChake()" name="email" />
                  <section id="errorEmail" class="text-danger"></section>
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                  <textarea class="textarea" placeholder="Enter Your Massage*" id="a1" onkeyup="locationa(this.value)"
                    required minlength="10" nmae="massage" maxlength="120" cols="30" rows="4"></textarea>
                  <section class="text-danger"  id="errorArea"></section>
                </div>
              </div>
              <div class="col-md-12 btnc">
                <button id="b2" type="submit" class="btn btn-primary">
                  <i class="fa fa-rocket pe-1"></i>Send Massage
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
  <!-- Footer -->
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-xl-4 col-sm-6 mb-5 mb-lg-0 mb-xl-0">
          <ul>
            <img class="mb-4" src="./images/A-FOODS Logo 5.png" alt="" />
            <p>
              Lorem Ipsum is simply dummy text of the prin ting and
              typesetting ind ustry. Lorem Ipsum has been the industry's sta
              ndard dummy.
            </p>
          </ul>
        </div>
        <div class="col-lg-3 col-xl-3 col-sm-6 mb-5 mb-lg-0 mb-xl-0 align-content-center">
          <h5 class="fw-bold heading">Quick Links</h5>
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="about-us.php">About us </a></li>
            <li><a href="menu bargur.php ">Menu </a></li>
            <li><a href="product.php">product</a></li>
            <li><a href="contact.php"> Contact</a></li>
          </ul>
        </div>
        <div class="col-lg-5 col-xl-5 col-sm-6 mb-5 mb-lg-xl-0">
          <h5 class="fw-bold pb-3">Newsletter</h5>
          <form action="subcribe.php" method="post">
          <div class="form-group mb-4">
            <input type="email" class="form-control" id="sub" name="email" placeholder="Enter Your Email" />
            <button  type="submit" class="btn btn-primary">Subcribe</button>
          </div>
        </form>
          <div class="icon">
            <a href="UCGjKJ1xC8UTPlcB3Dl-0MgQ" link="UCGjKJ1xC8UTPlcB3Dl-0MgQ" class="me-4"><svg
                xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="30"
                height="30" x="0" y="0" viewBox="0 0 512 512" style="enable-background: new 0 0 512 512"
                xml:space="preserve" class="hovered-paths">
                <g>
                  <path fill="#1877f2"
                    d="M512 256c0 127.78-93.62 233.69-216 252.89V330h59.65L367 256h-71v-48.02c0-20.25 9.92-39.98 41.72-39.98H370v-63s-29.3-5-57.31-5c-58.47 0-96.69 35.44-96.69 99.6V256h-65v74h65v178.89C93.62 489.69 0 383.78 0 256 0 114.62 114.62 0 256 0s256 114.62 256 256z"
                    opacity="1" data-original="#1877f2" class="hovered-path"></path>
                  <path fill="#ffffff"
                    d="M355.65 330 367 256h-71v-48.021c0-20.245 9.918-39.979 41.719-39.979H370v-63s-29.296-5-57.305-5C254.219 100 216 135.44 216 199.6V256h-65v74h65v178.889c13.034 2.045 26.392 3.111 40 3.111s26.966-1.066 40-3.111V330z"
                    opacity="1" data-original="#ffffff" class="me-2"></path>
                </g>
              </svg></a>
            <a href="#" class="me-4"><svg xmlns="http://www.w3.org/2000/svg" version="1.1"
                xmlns:xlink="http://www.w3.org/1999/xlink" width="30" height="30" x="0" y="0"
                viewBox="0 0 112.196 112.196" style="enable-background: new 0 0 512 512" xml:space="preserve"
                class="hovered-paths">
                <g>
                  <circle cx="56.098" cy="56.097" r="56.098" style="" fill="#007ab9" data-original="#007ab9"
                    class="hovered-path"></circle>
                  <path
                    d="M89.616 60.611v23.128H76.207V62.161c0-5.418-1.936-9.118-6.791-9.118-3.705 0-5.906 2.491-6.878 4.903-.353.862-.444 2.059-.444 3.268v22.524h-13.41s.18-36.546 0-40.329h13.411v5.715c-.027.045-.065.089-.089.132h.089v-.132c1.782-2.742 4.96-6.662 12.085-6.662 8.822 0 15.436 5.764 15.436 18.149zm-54.96-36.642c-4.587 0-7.588 3.011-7.588 6.967 0 3.872 2.914 6.97 7.412 6.97h.087c4.677 0 7.585-3.098 7.585-6.97-.089-3.956-2.908-6.967-7.496-6.967zm-6.791 59.77H41.27v-40.33H27.865v40.33z"
                    style="" fill="#f1f2f2" data-original="#f1f2f2" class=""></path>
                </g>
              </svg></a>
            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink"
                width="30" height="30" x="0" y="0" viewBox="0 0 152 152" style="enable-background: new 0 0 512 512"
                xml:space="preserve" class="">
                <g>
                  <g data-name="Layer 2">
                    <g data-name="04.Twitter">
                      <circle cx="76" cy="76" r="76" fill="#03a9f4" opacity="1" data-original="#03a9f4" class="">
                      </circle>
                      <path fill="#ffffff"
                        d="M125.23 45.47a42 42 0 0 1-11.63 3.19 20.06 20.06 0 0 0 8.88-11.16 40.32 40.32 0 0 1-12.8 4.89 20.18 20.18 0 0 0-34.92 13.8 20.87 20.87 0 0 0 .47 4.6 57.16 57.16 0 0 1-41.61-21.11 20.2 20.2 0 0 0 6.21 27 19.92 19.92 0 0 1-9.12-2.49v.22a20.28 20.28 0 0 0 16.17 19.82 20.13 20.13 0 0 1-5.29.66 18 18 0 0 1-3.83-.34 20.39 20.39 0 0 0 18.87 14.06 40.59 40.59 0 0 1-25 8.61 36.45 36.45 0 0 1-4.83-.28 56.79 56.79 0 0 0 31 9.06c37.15 0 57.46-30.77 57.46-57.44 0-.89 0-1.75-.07-2.61a40.16 40.16 0 0 0 10.04-10.48z"
                        opacity="1" data-original="#ffffff" class=""></path>
                    </g>
                  </g>
                </g>
              </svg></a>
          </div>
        </div>
      </div>
      <hr />
      <div class="copy text-center">
        <h6><span class="color">Copyright @ 2024 By</span> A-Foods || Developed By Aiman</h6>
      </div>
    </div>
  </footer>
  <script src="./Javascript/script.js"></script>
  <!-- javascript -->
  <script>
    function nameChake() {
      let name = document.getElementById("t1").value;
      let nameRegex = /^[a-zA-Z ]{4,15}$/;
      let test = nameRegex.test(name);
      console.log(test);
      if (test) {
        document.getElementById("b2").disabled = false;
        document.getElementById("t1").classList.remove("is-invalid");
        document.getElementById("errorName").innerHTML = "";
      } else {
        document.getElementById("b2").disabled = true;
        document.getElementById("t1").classList.add("is-invalid");
        document.getElementById("errorName").innerHTML = "Name Is Invalid";
      }
    }
    function emailChake() {
      let email = document.getElementById("t2").value;
      let emailRegex =
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      let test = emailRegex.test(email);
      console.log(test);
      if (test) {
        document.getElementById("b2").disabled = false;
        document.getElementById("t2").classList.remove("is-invalid");
        document.getElementById("errorEmail").innerHTML = "";
      } else {
        document.getElementById("b2").disabled = true;
        document.getElementById("t2").classList.add("is-invalid");
        document.getElementById("errorEmail").innerHTML =
          "Email Is Invalid ...";
      }
    }
    function locationa(loca) {
      console.log(loca);
      let localen = loca.length;
      console.log(localen);
      if (localen < 120) {
        document.getElementById("errorArea").innerHTML = "";
        document.getElementById("a1").classList.remove("is-invalid");
      } else {
        document.getElementById("errorArea").innerHTML =
          "You Can't Write More Then 120 Words...";
        document.getElementById("a1").classList.remove("is-invalid");
      }
    }
    function sunMit() {
      window.alert("✓ Send successfully");
    }
  </script>
  <!-- bootstrap js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
    crossorigin="anonymous"></script>
</body>

</html>