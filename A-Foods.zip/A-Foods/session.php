<?php
// session.php
session_start(); // Start the session

// You can set default session variables here if needed
if (!isset($_SESSION['initialized'])) {
    $_SESSION['initialized'] = true;
    // Other default session variables can be initialized here
}
?>