<?php
// print'<pre>';
// print_r($_POST);
// print_r($_FILES);

$name =$_POST['firname'].' '.$_POST['lasname'];
$phone=$_POST['Phone'];
$email=$_POST['email'];
$pass=$_POST['conpass'];

// image path
$fileName = time()."-".$_FILES['Avtare']['name'];
$tmpNamp =$_FILES['Avtare']['tmp_name'];
$fileType =$_FILES['Avtare']['type'];
$uploadsPath ='./uploads/';
$imagePath=$uploadsPath.$fileName;



const HOST = 'localhost';
const USER = 'root';
const PASS = '';
const DB = 'a-foods';

if($fileType =='image/jpg' || $fileType =='image/jpeg' || $fileType =='image/png' || $fileType =='image/gif'){
    move_uploaded_file($tmpNamp,$imagePath);
    $con = new MySQLi(HOST,USER,PASS,DB);
    if($con->connect_error){
        die($con->connect_error);

    }
  try{ 
    $SQL="insert into user(name,phone,email,pass,profile_pic)
    values('$name','$phone','$email','$pass','$imagePath')";
    $con->query($SQL);
    $rows=$con->affected_rows;
    if($rows==1){ 
        echo"<script>window.location.href='login.php'; window.alert('Created Successflly');</script>";
    }
    else{
        echo"<script>window.location.href='register.php'; window.alert('Uaer Allready Exist');</script>";
        
    }
    $con->close();}
    catch(Exception $e){
        echo $e->getMessage();
    }
    finally{
        echo"<script> window.alert('Uaer Allready Exist');window.location.href='register.html';</script>";

    }
}
else{
    echo"<script> window.alert('Only Image FIles are accepted....');window.location.href='register.html';</script>";        
}




?>