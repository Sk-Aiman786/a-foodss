<?php
$phone = $_POST['Phone'];
$pass = $_POST['pass'];

const HOST = 'localhost';
const USER = 'root';
const PASS = '';
const DB = 'a-foods';   

$con = new MySQLi(HOST,USER,PASS,DB);
if($con->connect_error){
    die($con->connect_error);
}else{
    $SQL = "SELECT * FROM user WHERE phone = '$phone' AND pass = '$pass'";
    $result = $con->query($SQL);
    $rows = $result->num_rows;
    $row = $result->fetch_array();
    $con->close();
    if($rows == 1){
        session_start();
        $_SESSION['phone'] = $phone;
        $_SESSION['id'] = $row['user_id'];
        header('location:index.php');
    }else{
        header('location:login-from.html');
    }
}
?>