<?php
print_r($_POST);
print_r($_FILES);
$name = $_POST['firname'].' '.$_POST['lasname'];
session_start();
$id = $_SESSION['id'];
echo $id;
$fileName = time()."-".$_FILES['Avtare']['name'];
$tmpNamp =$_FILES['Avtare']['tmp_name'];
$fileType =$_FILES['Avtare']['type'];
$uploadsPath ='./uploads/';
$imagePath=$uploadsPath.$fileName;

const HOST = 'localhost';
const USER = 'root';
const PASS = '';
const DB = 'a-foods';
$con = new MySQLi(HOST,USER,PASS,DB);
    if($con->connect_error){
        die($con->connect_error);
    }else{

        $SQL = "UPDATE user SET name = '$name' WHERE user_id = $id";
    $result = $con->query($SQL);        
    
    header('location:index.php');
    }
if($fileType =='image/jpg' || $fileType =='image/jpeg' || $fileType =='image/png' || $fileType =='image/gif'){
    move_uploaded_file($tmpNamp,$imagePath); 
    $SQL = "UPDATE user SET profile_pic = '$imagePath' WHERE user_id = $id";
    $result = $con->query($SQL);    
    $con->close();  
}else{
    echo "error";
}
?>