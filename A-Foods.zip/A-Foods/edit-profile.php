<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>A-Foods Login</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
      integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <style>
      .image-div{
        width: 125px;
        height: 125px;
border-radius: 100px;
/* overflow: hidden; */
      }
      .form-group img {
        width: 125px;
        height: 125px;
        border-radius: 100px;
        border: 3px solid #aeb4b7;
        object-fit: cover;
      }

      .form-group {
        position: relative;
        width: 100%;
      }

      .form-group .rounded {
        position: absolute;
        width: 30px;
        height: 30px;
        bottom: 0;
        top: 70%;
        left: 60%;
        right: 0;
      }

      .form-group .rounded input[type="file"] {
        position: absolute;
        width: 30px;
        height: 30px;
        transform: scale(2);
        opacity: 0;
      }

      .fa-camera{
        color: black;
      }
    </style>
  </head>

  <body>

    <?php

    include "header.php";

    ?>
    <div class="container">
      <div
        class="col-sm-8 offset-sm-2 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4 card text-center p-5"
      >
        <form action="edit.php" enctype="multipart/form-data" method="post" autocomplete="on">
          <div class="form-group mb-3 text-center">
            <div class="image-div d-flex mx-auto"> 
              <!-- <img
              id="image"
              src="./assets/blank-profile-picture-973460_640.png"
              class="uploder"
              alt=""
              /> -->
              <?php 

              const host = "localhost"; 
              const user = "root";
              const pass = "";
              const db = "a-foods";
              $con = new MySQLi(host,user,pass,db);
              if($con->connect_error){
                die($con->connect_error);
              }
                $SQL = "SELECT * FROM user WHERE user_id = $_SESSION[id]";
                $result = $con->query($SQL);
                $row = $result->fetch_array();
                $con->close();
              

              $a = $row['name'];
              $b =explode(" ",$a);
              $c = $b[0];
              $d = $b[1];

              echo '<img
              id="image"
              src='.$row['profile_pic'].'
              class="uploder"
              alt=""
              />';
              ?>
            </div>
            <div class="rounded">
              <input type="file" name="Avtare" id="file" />

              <i class="fa-solid fa-camera"></i>
            </div>
          </div>

          <div class="form-floating mb-3">
            <input
              required
              type="text"
              class="form-control"
              id="fname"
              onkeyup="valiDation('fname','fname-error',/^[A-Za-z 0-9@$%&_-]{2,10}$/,'invalid Name')"
              name="firname"
              placeholder="First Name"
              value="<?php echo $c; ?>"
            />
            <label for="floatingInput">First Name</label>
            <section class="text-danger text-start" id="fname-error" ></section>
          </div>
          <div class="form-floating mb-3">
            <input
              type="text"
              required
              class="form-control"
              id="lasname"
              name="lasname"
              onkeyup="valiDation('lasname','lasname-error',/^[A-Za-z 0-9@$%&_-]{2,10}$/,'invalid Name...')"
              placeholder="LAst Name"
              value="<?php echo $d; ?>"
            />
            <label for="floatingInput">Last Name</label>
            <section class="text-danger text-start" id="lasname-error" ></section>
          </div>
          <div class="form-group">
            <button type="submit" id="btn" class="btn btn-success form-control">
              Update
            </button>
          </div>
        </form>
      </div>
    </div>
    <!-- main script -->
    <script>
      // regex funtion component
      function valiDation(id,error,regex,iner){
        let name = document.getElementById(id).value;
        let nameRegex =regex;
        let  nametest=nameRegex.test(name);
        if(nametest){
          document.getElementById(error).innerHTML="";
          document.getElementById(id).classList.remove("is-invalid");
          document.querySelector("#btn").disabled=false;
        }
        else{
          document.getElementById(error).innerHTML=iner;
          document.getElementById(id).classList.add("is-invalid");
          document.querySelector("#btn").disabled=true;
          
        }
      } 

      // confirm passs
      function conPass(){
        let pass = document.getElementById('pass').value;
        let confirm_pass = document.getElementById('conpass').value;
        console.log(pass);
        console.log(confirm_pass);
        if(pass==confirm_pass){
          document.getElementById('conpass-error').innerHTML="";
          document.getElementById('conpass').classList.remove("is-invalid");
          
        }
        else{
          document.getElementById('conpass-error').innerHTML="Wrong Password...";
          document.getElementById('conpass').classList.add("is-invalid");
        }
      }
var image =document.getElementById('image');
var file =document.getElementById('file');
    file.addEventListener('change',(e)=>{
      let imagefile =e.target.files[0];
      image.src=URL.createObjectURL(imagefile);

    })  
    </script>

    <!-- bootstrap Script -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
