<?php
include "session.php";
print_r($_POST);
if(isset($_SESSION['phone'])){
   $id =$_SESSION['id'];
    $name = $_POST['name'];
$email = $_POST['email'];
$massage = $_POST['massage'];

$HOST = 'localhost';
$USER = 'root';
$PASS = '';
$DB = 'a-foods';

$con = new mysqli($HOST, $USER, $PASS, $DB);

if ($con->connect_error) {
    die('Connection Failed : '.$con->connect_error);
} else {
    $SQL = "INSERT INTO contact (name, email, massage , user_id) VALUES ('$name', '$email', '$massage','$id')";
    $con->query($SQL);
    $con->close();
    echo '<script>alert("Your message has been sent successfully."); window.location.href="index.php";</script>'; 
}
}
else{
    header('location:login-from.html');
}
?>
