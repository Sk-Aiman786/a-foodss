<?php
print_r($_POST);
include "session.php";
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(isset($_SESSION['phone'])){

        if(isset($_SESSION['card'])){
    $location = $_POST['location'];
    $contact = $_POST['phone'];
    $mathod = $_POST['payment'];
    $id = array_column($_SESSION['card'],'id');
    $ids = implode(',',$id);
    $name = array_column($_SESSION['card'],'name');
    $names = implode(',',$name);
    $quantity = array_column($_SESSION['card'],'quentity');
    $quantitys = implode(' ',$quantity);
    $price = $_SESSION['total'] ;


$HOST = 'localhost';
$USER = 'root';
   $PASS = '';
$DB = 'a-foods';
   $con = new MySQLi($HOST,$USER,$PASS,$DB);
   if($con->connect_error){
       die($con->connect_error);
   }else{
       $SQL = "INSERT INTO `orders`(`item_names`, `item_ids`, `price`, `location`, `c_number`, `user_id`, `quentity`, `method`) VALUES ('$names','$ids','$price','$location','$contact','$_SESSION[id]','$quantitys','$mathod')";
       $con->query($SQL);
       $con->close();
       echo"<script>window.location.href='card.php'; window.alert('Your order has been placed successfully');</script>";
       foreach($_SESSION['card'] as $key => $value){
            unset($_SESSION['card']);
        
    }
    }
}else{
    echo"<script>window.location.href='index.php'; window.alert('Please add item in card');</script>";
}
    }

    else{
        echo"<script>window.location.href='login-from.php'; window.alert('Please login first'); </script>";
    }
}
?>
