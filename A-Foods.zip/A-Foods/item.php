<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
    <?php
    const HOST = 'localhost'; 
    const USER = 'root';
    const PASS = '';
    const DB = 'a-foods';
    $con = new MySQLi(HOST,USER,PASS,DB);
    if($con->connect_error){
        die($con->connect_error);
    }
    $sql = "SELECT * FROM item";
    $result = $con->query($sql);
    $row = $result->fetch_array();
    $con->close();
    ?>
      <!-- menu -->
  <section id="Menu">
    <div class="title-menu text-center mb-5">
      <h5>Chef Recommends</h5>
      <p>Choose a perfect combination of main dish and wine, thanks to our Chef’s specials</p>
    </div>
    <div class="container">
      <div class="row">
  
                    <?php
                echo  '<img src='.$row['p_pic'].' alt="" />';
                  ?>

        <?php
  while($row = $result->fetch_array()){
   echo '<div class="col-sm-6">
   <form action="addCard.php" method="post" >
          <a href="product - 2.html">
            <div class="card">
              <div class="ditles">
                <div class="about-6">
                  <h4>'.$row['p_name'].'</h4>
                  <p>
                    '.$row['p_description'].'
                  </p>
                  <h5>
                    <span class="color-1"><strike>'.$row['prev_price'].'</strike></span> $'.$row['price'].'
                  </h5>
                    <button type="submit" name="submit" class="btn btn-primary mt-4" >Add To Card</button>
                </div>
                <div class="about-7">
                      <img src='.$row['p_pic'].' alt="" />
                </div>
              </div>
            </div>
          </a>

          <input type="hidden" name="image" value="'.$row['p_pic'].'" id="p_id">
          <input type="hidden" name="name" value="'.$row['p_name'].'" id="p_id">
          <input type="hidden" name="id" value="'.$row['p_id'].'" id="p_id">
          <input type="hidden" name="price" value="'.$row['price'].'" id="p_id">
          </form>
        </div>';
  }
  ?>

      </div>
    </div>
  </section>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>